# synesthesia_viz
###Jennifer Leung, Sophia Wang, Jeremy Su

View our project at [https://jleung97.github.io/synesthesia_viz/](https://jleung97.github.io/synesthesia_viz/)!
